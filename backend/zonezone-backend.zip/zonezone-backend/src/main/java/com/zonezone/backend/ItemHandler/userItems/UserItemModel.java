package com.zonezone.backend.ItemHandler.userItems;

public class UserItemModel {
}
