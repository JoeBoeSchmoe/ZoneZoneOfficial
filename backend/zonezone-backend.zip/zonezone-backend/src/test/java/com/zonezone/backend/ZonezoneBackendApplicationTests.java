package com.zonezone.backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZonezoneBackendApplicationTests {

    @Test
    void contextLoads() {
    }

}
